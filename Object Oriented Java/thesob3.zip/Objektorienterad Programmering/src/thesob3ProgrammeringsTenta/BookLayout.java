package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak

import java.util.Calendar;

public class BookLayout {

	Integer bookNo = 0;
	boolean loaned = false;
	boolean late = false;
	String bTitle = "";
	String bAuthor = "";
	String bGenre = "";
	int bPages = 0;
	Calendar loanedWhen;
	Calendar returnDate;

	boolean newBook(Integer bNo, boolean isLoaned, String title, String author, String genre, int pages) {

		try {
			bookNo = bNo;
			loaned = isLoaned;
			bTitle = title;
			bGenre = genre;
			bAuthor = author;
			bPages = pages;
			return true;
		} catch (Exception err) {
			return false;
		}
	}

	Integer getbNo() {
		return bookNo;
	}

	boolean isLoaned() {
		return loaned;
	}

	void setLoaned(boolean out) {
		if (out) {
			loanedWhen = Calendar.getInstance();
			returnDate = (Calendar) loanedWhen.clone();
			returnDate.add(Calendar.MONTH, 3);
			
			loaned = out;

		} else {
			
			loaned = out;
		}
		
	}
	
	boolean isLate()
	{
		if(returnDate.after(Calendar.getInstance()))
		{	late = true;
			return late;
		}
		else {
			return false;
		}
	}
	String getTitle() {
		return bTitle;
	}

	String getAuthor() {
		return bAuthor;
	}

}
