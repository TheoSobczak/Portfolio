package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak
public class Admins extends Members {
	/*	Account är basen till SavingsAccount, CreditAccount, och Accounthandler.
	 *  Den definerar grundstrukturen varpå resterande utökar / hanterar olika delar av kontohantering
	 */
	
	
	
	boolean makeLoan()
	{	
		
		return adminRights;
		
	}
	
	
	

}
