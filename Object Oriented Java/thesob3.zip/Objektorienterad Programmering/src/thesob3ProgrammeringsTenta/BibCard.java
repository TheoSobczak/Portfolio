package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak
import java.util.Calendar;

public class BibCard {
	
	Long socialSecNo;
	boolean valid;
	int bibCardNo;
	Calendar created;
	Calendar validUntil;

	boolean newCard(Long pNo, int cardNo) {
		try {
			socialSecNo = pNo;
			bibCardNo = cardNo;
			created = Calendar.getInstance();
			validUntil = (Calendar) created.clone();
			validUntil.add(Calendar.YEAR, 2);
			return true;
		} catch (Exception err) {
			return false;
		}

	}

	int getbibNo() {
		return bibCardNo;
	}

	boolean isValid() {
		Calendar now = Calendar.getInstance();
		if (now.after(validUntil)) {
			return false;
		} else {
			return true;
		}
	}
	
	boolean appliedFor(boolean decision) {
		valid = decision;
		return valid;
	}
	
	Long getOwnerPno() {
		
		return socialSecNo;
	}

}
