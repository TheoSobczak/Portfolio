package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak
import java.util.ArrayList;

public class Users extends Members {
	/*	Account är basen till SavingsAccount, CreditAccount, och Accounthandler.
	 *  Den definerar grundstrukturen varpå resterande utökar / hanterar olika delar av kontohantering
	 */
	
	ArrayList <Integer> loans = new ArrayList <Integer>();
	int bibCardNo = 0;
	boolean hasBibCard = false;
	boolean pendingApplication = false;
	Float debt;
	
	boolean bibCardExist()
	{
		return hasBibCard;
	}
	
	void appliedforBibCard()
	{	
		pendingApplication = true;
	}
	
	ArrayList <Integer>  getLoans()
	{
		return loans;
	}
	
	boolean addLoan(int bNo)
	{	
		loans.add(bNo);
		return true;
	}
	
	boolean removeLoan(int bNo)
	{	
		loans.remove(bNo);
		return true;
	}
	
	boolean linkBibCard(int bibNo)
	{
		bibCardNo = bibNo;
		hasBibCard = true;
		return hasBibCard;
	}
	
	boolean removeBibCard()
	{
		bibCardNo = 0;
		hasBibCard = false;
		return true;
	}
	
	void addDebt(Float amount)
	{
		debt += amount;
	}

	

}
