package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class LibraryInterface {

	public static void main(String[] args) {
		
		
		LibraryMain libMain = new LibraryMain();
		JFrame frame = new JFrame("Lib interface"); // Huvudframe

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon img = new ImageIcon(System.getProperty("user.dir") + "\\src\\thesob3ProgrammeringsTenta\\" + "book.jpeg");
		frame.setIconImage(img.getImage());
		JTextArea consoleWindowT = new JTextArea();
		consoleWindowT.setBackground(Color.WHITE);
		JScrollPane consoleWindow = new JScrollPane(consoleWindowT); // Konsolfönster för återapportering
		frame.add(consoleWindow); // Lägg till i huvudfönster med layout FlowLayout
		
		frame.setVisible(true); // Exhibit the frame

		JMenuBar menuBar = new JMenuBar();
		UIManager.put("MenuBar.background", Color.YELLOW);

		JMenu fileMenu = new JMenu("File"); // Meny fält File
		fileMenu.setMnemonic(KeyEvent.VK_F);
		menuBar.add(fileMenu);
		
		JMenuItem exportB = new JMenuItem(new AbstractAction("Export") {

			public void actionPerformed(ActionEvent e) {
				libMain.export();
				// TODO Auto-generated method stub
				
			}});
		
		JMenuItem importB = new JMenuItem(new AbstractAction("Import") {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent e) {
				libMain.importBooks();
				consoleWindowT.setText("Import successfull");
				
				// TODO Auto-generated method stub
				
			}});
		
		fileMenu.add(importB);
		fileMenu.add(exportB);

		JMenu loginMenu = new JMenu("Login"); // Meny fält Customer
		loginMenu.setMnemonic(KeyEvent.VK_L);
		menuBar.add(loginMenu);

		JMenu bookMenu = new JMenu("Books"); // Meny fält Transaktioner
		bookMenu.setMnemonic(KeyEvent.VK_B);
		bookMenu.setEnabled(false);
		menuBar.add(bookMenu);
		frame.getContentPane().setBackground(Color.WHITE);
		
		JMenu UserMenu = new JMenu("Users"); // Meny fält Transaktioner
		UserMenu.setMnemonic(KeyEvent.VK_B);
		UserMenu.setEnabled(false);
		menuBar.add(UserMenu);
		frame.getContentPane().setBackground(Color.WHITE);
		
		JMenu adminsMenu = new JMenu("Admins"); // Meny fält Transaktioner
		adminsMenu.setMnemonic(KeyEvent.VK_B);
		adminsMenu.setEnabled(false);
		menuBar.add(UserMenu);
		frame.getContentPane().setBackground(Color.WHITE);
		
		JMenu helpMenu = new JMenu("Help"); // Meny fält Transaktioner
		helpMenu.setMnemonic(KeyEvent.VK_H);
		helpMenu.setEnabled(false);
		menuBar.add(helpMenu);
		frame.getContentPane().setBackground(Color.WHITE);

		GridLayout experimentLayout = new GridLayout(0, 2);
		frame.setLayout(experimentLayout);

		JLabel label = new JLabel(); // JLabel Creation för ikon

																												
		frame.add(label);

		
	
		
		frame.setJMenuBar(menuBar);
		frame.setSize(700, 350);
		frame.setVisible(true);
		
	}

}
