package thesob3ProgrammeringsTenta;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Scanner;

//thesob3
//Theo sobczak
public class LibraryMain {

	static ArrayList<BookLayout> books = new ArrayList<BookLayout>();
	static ArrayList<Users> userMembers = new ArrayList<Users>();
	ArrayList<Admins> admins = new ArrayList<Admins>();
	ArrayList<BibCard> cardList = new ArrayList<BibCard>();

	int cardNo = 10000;
	int bookNo = 0;


	boolean export() {
		return true;
	}

	boolean importBooks() {
		
		/**
		 * Importerar csv filen och lägger in böckerna i databasen
		 */
		File file = new File(System.getProperty("user.dir") + "\\src\\thesob3ProgrammeringsTenta\\" + "books.csv"); 
		try (Scanner sc = new Scanner(file)) {
			int count = 0;
			while (sc.hasNextLine()) {
				String[] textline = sc.nextLine().split(";");
				if(count == 0)
					{count ++;}
				else {
					BookLayout addingBook = new BookLayout();
					addingBook.newBook(bookNo, false, textline[0], textline[1], textline[2],Integer.parseInt(textline[3]));
					books.add(addingBook);
					bookNo++;
				}
					
			}
		} catch (Exception err) {
			System.out.println(err);
			return false;
		}

		return true;
	}

	boolean makeLoan(Long userpNo, Long adminPno, Integer bNo) {
		
		/**
		 * Gör ett lån, måste göras med adminrättigher. Grundtanken är att innan makeloan sker det en check med hasAdminRights
		 */
		
		boolean validLoan = false;
		for (Admins admin : admins) {
			if (admin.getpNo().equals(adminPno)) {
				validLoan = true;
			} 
		}

		for (Users user : userMembers) {
			if (user.getpNo().equals(userpNo) && user.bibCardExist()) {
				for (BookLayout book : books) {
					if (Integer.valueOf(book.getbNo()).equals(bNo)) {
						book.setLoaned(true);
						user.addLoan(bNo);
						return validLoan;
					}
				}
			} 
		}

		return false;
	}
	
	boolean returnLoan(Long userpNo, Long adminPno, int bNo)
	{	
		/**
		 * Gör en retur
		 */
		boolean validReturn = false;
		for (Admins admin : admins) {
			if (admin.getpNo().equals(adminPno)) {
				validReturn = true;
			} 
		}

		for (Users user : userMembers) {
			if (user.getpNo().equals(userpNo) && user.bibCardExist()) {
				for (BookLayout book : books) {
					if (book.getbNo() == bNo && book.isLoaned()) {
						book.setLoaned(false);
						if(book.isLate())
						{
							user.addDebt((float) 20);
						}
						user.removeLoan(bNo);
						return validReturn;
					}
				}
			}
		}
		return false;
	}

	boolean addUserMember(Long pNo, boolean memberRights, String firstName, String lastName, String streetAdress,
			BigDecimal phoneNumber,String username,String pw) {
		
		/**
		 * Skapar en user användare
		 */
		for (Users user : userMembers) { // Om den redan finns så false
			if (user.getpNo().equals(pNo)) {
				return false;
			}
		}
		Users newUser = new Users();
		if (newUser.newMember(pNo, memberRights, firstName, lastName, streetAdress, phoneNumber)) {
			newUser.setLoginCred(username, pw);
			userMembers.add(newUser); // Lägg till i userlistan
			return true;
		} else {
			return false;
		}

	}

	boolean addAdminMember(Long pNo, boolean memberRights, String firstName, String lastName, String streetAdress,
			BigDecimal phoneNumber, String username, String pw) {
		
		/**
		 * Skapar en Admin användare
		 */
		for (Admins admin : admins) {
			if (admin.getpNo().equals(pNo)) {
				return false;
			}
		}
		Admins newAdmin = new Admins();
		if (newAdmin.newMember(pNo, memberRights, firstName, lastName, streetAdress, phoneNumber)) {
			newAdmin.setLoginCred(username, pw);
			admins.add(newAdmin);
			return true;
		} else {
			return false;
		}
	}

	boolean addBook(int bNo, String title, String author, String genre, int pages) {
		
		/**
		 * Lägg till en bok i biblioteket
		 */
		for (BookLayout book : books) {
			if (book.getbNo() == bNo) // already exist
			{
				return false;
			}
		}

		BookLayout newBook = new BookLayout();
		if (newBook.newBook(bNo, false, title, author, genre, pages)) {
			books.add(newBook);
			return true;
		} else {
			return false;
		}
	}

	boolean addbibCard(Long pNo) {
		/**
		 * Skapa ett bibliotekskort
		 */
		for (Users user : userMembers) {
			if (user.getpNo().equals(pNo) && user.bibCardExist()) {
				return false;
			}
		}
		for(BibCard card : cardList)
		{
			if(cardNo == card.getbibNo())
			{
				cardNo++;
			}
		}
		

		BibCard newCard = new BibCard();
		newCard.newCard(pNo, cardNo);
		for (Users user : userMembers) {
			if (user.getpNo().equals(pNo)) {
				user.linkBibCard(cardNo); //Länka det till användare
			}
		}

		cardList.add(newCard);
		cardNo++;
		return true;
	}

	boolean hasValidCard(Long pNo) {
		/**
		 * Check om användare har ett giltigt bilbiotekskort
		 */
		for (Users user : userMembers) {
			if (user.getpNo().equals(pNo) && user.bibCardExist()) {
				return true;
			}
		}
		return false;
	}
	
	ArrayList<Long> pendingApplications ()
	{	
		/**
		 * Returnar en lista med alla som väntar på att få sitt bilbiotekskort godkänt
		 */
		ArrayList<Long> applicants = new ArrayList<Long>();
		for (Users user : userMembers) {
			if (user.pendingApplication) {
				applicants.add(user.getpNo());
			}
		}
		return applicants;
	}

	boolean removeAdmin(Long pNo) {
		
		/**
		 * Ta bort Admin
		 */
		for (Admins admin : admins) {
			if (admin.getpNo().equals(pNo)) {
				admins.remove(admin);
				return true;
			}
		}
		return false;
	}

	boolean removeUser(Long pNo) {
		/**
		 * Ta bort användare
		 */
		for (Users user : userMembers) {
			if (user.getpNo().equals(pNo)) {
				userMembers.remove(user);
				return true;
			}
		}
		return false;
	}

	boolean removeBook(int bNo) {
		/**
		 * Ta bort bok
		 */
		for (BookLayout book : books) {
			if (book.getbNo() == (bNo)) {
				books.remove(book);
				return true;
			}
		}
		return false;
	}
	
	boolean removeBibCard(Long pNo) {
		
		/**
		 * Ta bort bibkort och rensa från användare
		 */
		
		for(BibCard card : cardList)
		{
			if(card.getOwnerPno().equals(pNo))
			{	
				for(Users user : userMembers)
				{
					if(card.getOwnerPno().equals(user.getpNo()))
					{
						user.removeBibCard();
					}
				}
				
				cardList.remove(card);
			}
		}

		return false;
	}
}
