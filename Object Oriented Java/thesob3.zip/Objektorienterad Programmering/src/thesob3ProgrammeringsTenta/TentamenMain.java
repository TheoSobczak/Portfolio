package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

public class TentamenMain {

	public static void main(String[] args) {
		
		LibraryMain libMain = new LibraryMain();
		
		libMain.addUserMember(9306011637L, false, "Theo", "Sobczak", "Liljegatan 4a",new BigDecimal("0707803988"), "thesob3", "123");
		libMain.addUserMember(9306012055L, false, "Emilia", "Petterson", "Sturegatan 4a",new BigDecimal("0707803980"), "emipet3", "123");
		
		libMain.addAdminMember(9306012055L, true, "Ragnar", "Petterson", "Geijersgatan 4a",new BigDecimal("0707803989"), "Ragn2", "123");
		
		libMain.importBooks();
		
		for(BookLayout book : libMain.books)
		{
			System.out.println(book.getTitle());
		}
		
		if(libMain.hasValidCard(9306011637L))
		{
			System.out.println("No valid card");
		}
		else {
			System.out.println("Valid card");
		}
		
		
		Integer i = 0;
		if(libMain.makeLoan(9306012055L, 9306012055L, i)) // Göra ett lån utan bib kort eller med admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		libMain.addbibCard(9306012055L); //Skapa ett bibkort
		
		for(Users user : libMain.userMembers)
		{	
			if(user.bibCardExist())
			{
				System.out.println("Has bib Card");
			}
			else {
				System.out.println("no bib card");
			}
		}
		
		if(libMain.makeLoan(9306012055L, 9306011637L, i)) // Utan admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		if(libMain.makeLoan(9306012055L, 9306012055L, i)) // Med Admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		for(Users user : libMain.userMembers)
		{	
			
			System.out.println(user.getLoans()); // Ska returnera att det finns boknumret lånat
		}
		
		for(BookLayout book : libMain.books)
		{	
			if(book.isLoaned())
			{	
				System.out.println(book.getTitle());
				System.out.println("book is loaned");
				System.out.println(book.loanedWhen.toString()); //Har inte tid att dateformatta den men den stämmer
			}
			else {
				
			}
		}
		
		
		
	}

}
