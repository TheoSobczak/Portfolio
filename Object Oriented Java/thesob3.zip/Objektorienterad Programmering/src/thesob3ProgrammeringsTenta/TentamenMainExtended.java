package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

public class TentamenMainExtended {

	public static void main(String[] args) {
		
		LibraryMain libMain = new LibraryMain();
		
		libMain.addUserMember(9306011637L, false, "Theo", "Sobczak", "Liljegatan 4a",new BigDecimal("0707803988"), "thesob3", "123");
		libMain.addUserMember(9306012055L, false, "Emilia", "Petterson", "Sturegatan 4a",new BigDecimal("0707803980"), "emipet3", "123");
		
		libMain.addAdminMember(9306012055L, true, "Ragnar", "Petterson", "Geijersgatan 4a",new BigDecimal("0707803989"), "Ragn2", "123");
		
		libMain.importBooks();
		
		for(BookLayout book : libMain.books)
		{
			System.out.println(book.getTitle());
		}
		
		Integer i = 1;
		if(libMain.makeLoan(9306012055L, 9306012055L, i)) // Göra ett lån utan bib kort eller med admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		
		
		if(libMain.hasValidCard(9306012055L))
		{
			System.out.println("9306012055L: " + "Valid card");
		}
		else {
			System.out.println("9306012055L: " +"No Valid card");
		}
		
		libMain.addbibCard(9306012055L); //Skapa ett bibkort
		
		if(libMain.hasValidCard(9306012055L))
		{
			System.out.println("9306012055L: " +"Valid card");
		}
		else {
			System.out.println("9306012055L: " +"No Valid card");
		}
	
		
		for(Users user : libMain.userMembers)
		{	
			if(user.bibCardExist())
			{
				System.out.println(user.getpNo()+": Has bib Card");
			}
			else {
				System.out.println(user.getpNo()+": No bib card");
			}
		}
		
		if(libMain.makeLoan(9306012055L, 9306011637L, i)) // Utan admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		if(libMain.makeLoan(9306012055L, 9306012055L, i)) // Med Admin rättigheter
		{
			System.out.println("Loan made");
		}
		else {
			System.out.println("Loan not made");
		}
		
		for(Users user : libMain.userMembers)
		{	
			
			System.out.print(user.getpNo()+": has following bookNo on loan: "+user.getLoans() + " "); // Ska returnera att det finns boknumret lånat
			if(user.getLoans().size()> 0)
			{for (BookLayout book : libMain.books)
				{
				if(user.getLoans().contains(book.getbNo()))
				{
					System.out.println(" Title of the book is "+ book.getTitle());
				}
				}
			}
			
		}
		
		for(BookLayout book : libMain.books)
		{	
			if(book.isLoaned())
			{	
				System.out.println("book is loaned :"+ book.getTitle() + " bookNo: " + book.getbNo());
				System.out.println("book was loaned :"+ book.loanedWhen.getTime());
				System.out.println("book too be returned on :"+ book.returnDate.getTime()); 
			}
			else {
				
			}
		}
		
		System.out.println("Following users has applied for bib carc "+libMain.pendingApplications()); // Hämta dom som har ansökt om bib kort
		
		for(Users user : libMain.userMembers)
		{	
				if(!user.bibCardExist())		// Om användaren inte har ett bib kort
				{
					user.appliedforBibCard(); // Ansök om bib kort
				}		
		}
		
		System.out.println("Following users has applied for bib carc "+libMain.pendingApplications()); // Hämta dom som har ansökt om bib kort
	
		for(BibCard card : libMain.cardList)
		{	
			System.out.println("Card "+ card.getbibNo() + " has this owner :"+ card.getOwnerPno()+ " and has valid status :" + card.isValid()); //
		}	
		
	//	libMain.returnLoan(9306012055L, 9306012055L, i);
		
	//	libMain.removeBibCard(9306012055L);
		
		for(Users user : libMain.userMembers)
		{	
			if(user.bibCardExist())
			{
				System.out.println(user.getpNo()+": Has bib Card");
			}
			else {
				System.out.println(user.getpNo()+": No bib card");
			}
		}
		
		for(Users user : libMain.userMembers)
		{	
			System.out.println("Users in the system " +user.getpNo()+" ");
		}
		
		libMain.removeUser(9306011637L);
		System.out.println("Removed user 9306011637L");
		
		for(Users user : libMain.userMembers)
		{	
			System.out.println("Users in the system " +user.getpNo());
		}
		
		System.out.println("Finding book bno " + i);
		for(BookLayout book : libMain.books)
		{	
			if(book.getbNo().equals(i))
			{
				System.out.println(book.getTitle());
			}
			
		}
		
		System.out.println("removing book no " + i);
		
		libMain.removeBook(i);
		
		System.out.println("Finding book bno " + i);
		for(BookLayout book : libMain.books)
		{	
			if(book.getbNo().equals(i)) {
				System.out.println(book.getTitle());
			}
			
		}
	}

}
