package thesob3ProgrammeringsTenta;
//thesob3
//Theo sobczak

import java.math.BigDecimal;

public abstract class Members {
	/*	Account är basen till SavingsAccount, CreditAccount, och Accounthandler.
	 *  Den definerar grundstrukturen varpå resterande utökar / hanterar olika delar av kontohantering
	 */
	
	Long socialSecNo;
	String fName = "";
	String lName = "";
	String adress ="";
	String username ="";
	String pw = "";
	BigDecimal phoneNum;
	boolean adminRights = false;
	
	boolean newMember(Long pNo, boolean memberRights, String firstName, String lastName, String streetAdress, BigDecimal phoneNumber )
	{	
		/*
		 * transaction skapar ett nytt hashmap objekt och populerar vår arraylist med informationen.
		 */
		try {
			socialSecNo = pNo;
			adminRights = memberRights;
			fName = firstName;
			lName = lastName;
			adress = streetAdress;
			phoneNum = phoneNumber;
			return true;
		}
		catch(Exception err)
		{
			return false;
		}
	}
	
	boolean validLoginCred(String usern, String password)
	{
		try {
			if(usern.equals(usern) && pw.equals(password))
			{
				return true;
			}
			else {
				return false;
			}
			
		}
		catch(Exception e)
		{
			return false;
		}
	}
	
	
	boolean setLoginCred(String usern, String password)
	{
		try {
			username= usern;
			pw = password;
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	Long getpNo()
	{
		return socialSecNo;
	}
	boolean adminRights()
	{
		return adminRights;
	}
	String getAdress()
	{
		return adress;
	}

	

}
